$(document).ready(
    function () {    
    MapPublicHolidays();
});