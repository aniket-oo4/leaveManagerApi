$(document).ready(  function ()
{
    debugger
    MapPublicHolidays();

}
);